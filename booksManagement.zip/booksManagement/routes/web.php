<?php

use Illuminate\Support\Facades\Route;

Route::get('/', '\App\Http\Controllers\LoginController@index');
Route::get('/admin/dashboard', '\App\Http\Controllers\BookController@index');

Route::post('/main/checklogin', '\App\Http\Controllers\LoginController@checklogin');
Route::get('/main/successlogin', '\App\Http\Controllers\LoginController@successlogin');
Route::get('/main/logout', '\App\Http\Controllers\LoginController@logout');

Route::get('/admin/addnew-book', '\App\Http\Controllers\BookController@addNewBook');
Route::post('/admin/addnew-book', '\App\Http\Controllers\BookController@addNewBook');
Route::get('/admin/book-list', '\App\Http\Controllers\BookController@bookList');
Route::post('/admin/update-book-details', '\App\Http\Controllers\BookController@updateBookdetails');
Route::post('/admin/delete-book', '\App\Http\Controllers\BookController@deleteBook');

Route::get('/admin/addnew-category', '\App\Http\Controllers\BookController@addNewCategory');
Route::post('/admin/addnew-category', '\App\Http\Controllers\BookController@addNewCategory');
Route::post('/admin/update-book-category', '\App\Http\Controllers\BookController@updateBookCategory');
Route::post('/admin/delete-category', '\App\Http\Controllers\BookController@deleteBookCategory');