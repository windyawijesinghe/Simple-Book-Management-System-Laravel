
<body>
    <section id="container" class="">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section id="main-content">
            <section class="wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header"><i class="fa fa-laptop"></i> Dashboard</h3>
                        <ol class="breadcrumb">
                            <li><i class="fa fa-home"></i><a href="/admin/dashboard">Home</a></li>
                            <li><i class="fa fa-laptop"></i>Book Category</li>
                        </ol>
                    </div>
                </div>
                <?php if(count($errors) > 0): ?>
                <div class = "alert alert-danger">
                   <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </ul>
                </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-lg-12">
                        <section class="panel">
                            <header class="panel-heading">Add New Category</header>
                            <div class="panel-body">
                                <div class="form">
                                    <form class="form-validate form-horizontal" name="add_category_form" id="add_category_form" action="/admin/addnew-category" method="post">
                                        <?php if(session()->has('success')): ?>
                                        <div class="alert alert-success" id="alert-success"  style="padding: 7px 5px;">
                                              <?php echo e(session()->get('success')); ?>

                                        </div>
                                        <?php endif; ?>
                                        <?php if(session()->has('error')): ?>
                                        <?php $__currentLoopData = session()->get('error'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="alert alert-danger" id="alert-danger" style="padding: 7px 5px;">
                                                  <?php echo e($value); ?>

                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group ">
                                            <label for="booktitle" class="control-label col-lg-2">Book Catergory<span class="required">*</span></label>
                                            <div class="col-lg-10">
                                                <input type="text" class="form-control" id="category" name="category_name" placeholder="Enter Book catergory name" />
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label for="author" class="control-label col-lg-2">Book Description</label>
                                            <div class="col-lg-10">
                                                <input type="text" class="form-control" id="description" name="description" placeholder="Enter Book description ">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-lg-offset-2 col-lg-10">
                                                <button id="add_category" class="btn btn-primary" type="submit">Save</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <?php
                $category_list = !empty($category_list) ? $category_list :'';
                ?>
                <div class="row">
                    <div class="col-lg-12">
                        <section class="panel">
                            <header class="panel-heading">Book Category List</header>
                            <table class="table table-striped table-advance table-hover">
                                <tbody>
                                    <tr>
                                        <th> ID </th>
                                        <th> Catergory name </th>
                                        <th> Category Description </th>
                                        <th> &nbsp; </th>
                                        <th><i class="icon_cogs"></i> Action</th>
                                    </tr>
                                <?php if(isset($category_list) && count($category_list)>0): ?>
                                    <?php $__currentLoopData = $category_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php
                                        $id = !empty($category->id) ? $category->id :'' ;
                                        $name = !empty($category->name) ? $category->name :'' ;
                                        $description = !empty($category->description) ? $category->description :'' ;
                                      ?>
                                    <tr class="edit-dis-table">
                                        <td>
                                            <?php echo e($id); ?>

                                            <input type="hidden" class="id" value="<?php echo e($id); ?>" />
                                        </td>
                                        <td> <input type="text" class="form-control cat_name" value="<?php echo e($name); ?>" disabled="" ></td>
                                        <td> <input type="text" class="form-control cat_description" value="<?php echo e($description); ?>" disabled="" ></td>
                                        <td><span class="cat_msg"></span></td>
                                        <td> 
                                            <ul class="list-inline m-0">
                                                <li class="list-inline-item">
                                                    <a href="javascript:void();" class="btn btn-warning edit_bP tbl-edit-view-btn" onclick="update_category(this);">Edit</a>
                                                    <a href="javascript:void();" onclick="save_book_category(this)" class="btn btn-success edit_bP hidden tbl-update-btn" >Update</a>
                                                </li>
                                                <li class="list-inline-item">
                                                    <a href="javascript:void();" class="btn btn-danger delete_category" data-cat-id="<?php echo e($id); ?>"  onclick="delete_book_category(this)">Delete</a>
                                                </li>
                                            </ul>
                                        </td>
                                        <span id="msg_view_<?php echo e($id); ?>" style="display: none;"></span>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr><td colspan="20" style="text-align: center"> No Records Found.</td></tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </section>
                    </div>
                    <div class="col-md-12 text-right">
                        <div class="pull-right">
                          <?php if(!empty($category_list)): ?>
                            <?php echo e($category_list->links()); ?>

                          <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php echo $__env->make('layouts.footer_credit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>
        </section>
    </section>
</body>
<script>

setTimeout(function() {
$('#alert-success').fadeOut('fast');
}, 3000);

$(document).ready(function() {
    $("#add_category").on("click", function(event) {
        $("#add_category_form").valid();
    })
});

function update_category(this_id){
if($(this_id).closest("tr").hasClass("edit-dis-table")){
    $(this_id).addClass("hidden");
    $(this_id).closest("td").find(".tbl-update-btn").removeClass("hidden");
    $(this_id).closest("td").find(".tbl-delete-btn").removeClass("hidden");
    $(this_id).closest("tr").removeClass("edit-dis-table");
    $(this_id).closest("tr").addClass("edit-enable-table");
    $(this_id).closest("tr").find(".form-control").removeAttr("disabled");
}
} 
function save_book_category(this_id){
    var cat_id = $(this_id).closest("tr").find(".id").val();
    var cat_name = $(this_id).closest("tr").find(".cat_name").val();
    var cat_description = $(this_id).closest("tr").find(".cat_description").val();
    $.ajax({
        type: "POST",
        url: "/admin/update-book-category",
        data: {"_token" : "<?php echo e(csrf_token()); ?>",cat_id:cat_id,cat_name:cat_name,cat_description:cat_description},
        success: function (data,textStatus, jQxhr) {
            $(this_id).closest("tr").find(".cat_msg").text("");
            if(data.success == 1){
                $(this_id).closest("tr").find(".cat_msg").css('color','green').text("Updated!!").show();
            }else{
                $(this_id).closest("tr").find(".cat_msg").css('color','red').text("Failed to update!!").show();
            }
            
            $(this_id).closest("tr").find(".tbl-edit-view-btn").removeClass("hidden");
            $(this_id).addClass("hidden");
            $(this_id).closest("tr").removeClass("edit-enable-table");
            $(this_id).closest("tr").addClass("edit-dis-table");
            $(this_id).closest("tr").find(".form-control").attr("disabled","disabled");
            setTimeout(function () {
                $(this_id).closest("tr").find(".cat_msg").hide();
            }, 1500);
            },
        error: function (jqXhr, textStatus, errorThrown) {
            console.log(errorThrown);
        }
    });
}

function delete_book_category(this_id){

var delete_confirmation = confirm("Do you want to delete this category?");
if(!delete_confirmation) {
    return false;
}
var cat_id = $(this_id).attr("data-cat-id");
$.ajax({
    type: "POST",
    url: "/admin/delete-category",
    data: {"_token" : "<?php echo e(csrf_token()); ?>",cat_id : cat_id},
    cache: false,
    success: function(data, textStatus, jQxhr) {
        if(data.success == 1) {
            window.location.reload();
        }
    },
    error: function(jqXhr, textStatus, errorThrown) {
        console.log(errorThrown);
    }
});

}
</script>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\BooksManagementSystem\booksManagement\resources\views/categories/add_new_category.blade.php ENDPATH**/ ?>