<script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
<script src="/assets/js/jquery-ui-1.10.4.min.js"></script>
<script src="/assets/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery-ui-1.9.2.custom.min.js"></script>
<!-- bootstrap -->
<script src="/assets/js/bootstrap.min.js"></script>
<!-- nice scroll -->
<script src="/assets/js/jquery.scrollTo.min.js"></script>
<script src="/assets/js/jquery.nicescroll.js" type="text/javascript"></script>

<!--custome script for all page-->
<script src="/assets/js/scripts.js"></script>
<!-- custom script for this page-->
<script src="/assets/js/jquery.slimscroll.min.js"></script>
<?php /**PATH E:\xampp\htdocs\BooksManagementSystem\booksManagement\resources\views/layouts/footer.blade.php ENDPATH**/ ?>