<section class="wrapper">
    <div class="text-right">
        <div class="credits">
            Designed by <a href="#">windya</a>
        </div>
    </div>
</section><?php /**PATH E:\xampp\htdocs\BooksManagementSystem\booksManagement\resources\views/layouts/footer_credit.blade.php ENDPATH**/ ?>