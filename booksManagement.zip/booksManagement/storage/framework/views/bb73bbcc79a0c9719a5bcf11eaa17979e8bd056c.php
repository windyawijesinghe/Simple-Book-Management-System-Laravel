
<body>
    <section id="container" class="">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section id="main-content">
            <section class="wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header"><i class="fa fa-laptop"></i> Dashboard</h3>
                    </div>
                    <div class="col-lg-10">
                        <ol class="breadcrumb">
                            <li><i class="fa fa-home"></i><a href="/admin/dashboard">Home</a></li>
                            <li><i class="fa fa-laptop"></i>Dashboard</li>
                        </ol>
                    </div>
                    <div class="col-lg-2">
                        <div class="btn">
                            <a href="/admin/addnew-book" button class="btn btn-primary btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="Add"> <i class="fa fa-plus" style="margin-right: 5px;"></i> Create</a>
                        </div>
                    </div>
                </div>
                <div class="row">
                <?php
                    $book_list = !empty($book_list) ? $book_list :'';
                ?>
                <?php if(isset($book_list) && count($book_list)>0): ?>
                    <?php $__currentLoopData = $book_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $name = !empty($book->name) ? $book->name :'' ;
                            $image = !empty($book->image) ? $book->image :'' ;
                            $author_name = !empty($book->author_name) ? $book->author_name :'' ;
                            $published_date = !empty($book->published_date) ? date("d/m/Y", strtotime($book->published_date))  :'' ;
                        ?>
                    <div class="col-lg-4">
                        <section class="panel">
                            <div class="panel-body">
                                <div class="thumbnail">
                                    <img class="group list-group-image" src="<?php echo e(asset('/images/'.$image)); ?>" style="height:100px; width:100px; margin-left: inherit;"alt="">
                                    <div class="caption" style=" padding-top: 16px;">
                                        <h4 class="group inner list-group-item-heading" style="font-weight: bold;"> <?php echo e($name); ?></h4>
                                        <p class="group inner list-group-item-heading">  Author : <?php echo e($author_name); ?></p>
                                        <div class="row">
                                            <div class="col-xs-12 col-md-12">
                                                <p class="lead " style="font-size: 15px;"><?php echo e($published_date); ?></p>
                                            </div>
                                            <?php
                                            $title = 'View'.' '.$name;
                                            ?>
                                            <div class="btn">
                                                <a href="/admin/book-list" button class="btn btn-primary btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="<?php echo e($title); ?>"><i class="fa fa-eye" aria-hidden="true" style="margin-right: 5px;"></i> View Book</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr><td colspan="20" style="text-align: center"> No Records Found.</td></tr>
                <?php endif; ?>
                </div>
                <?php echo $__env->make('layouts.footer_credit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>
        </section>
    </section>
</body>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\BooksManagementSystem\booksManagement\resources\views/index.blade.php ENDPATH**/ ?>