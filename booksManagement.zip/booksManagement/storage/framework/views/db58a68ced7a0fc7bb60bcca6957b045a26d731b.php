
<body>
    <section id="container" class="">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section id="main-content">
            <section class="wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header"><i class="fa fa-laptop"></i> Dashboard</h3>
                        <ol class="breadcrumb">
                            <li><i class="fa fa-home"></i><a href="index.html">Home</a></li>
                            <li><i class="fa fa-laptop"></i>Book List</li>
                        </ol>
                    </div>
                </div>
                <?php
                $book_list = !empty($book_list) ? $book_list :'';
                ?>
                <div class="row">
                    <div class="col-lg-12">
                        <section class="panel">
                            <header class="panel-heading">Book List</header>
                            <table class="table table-striped table-advance table-hover">
                                <tbody>
                                    <tr>
                                        <th> BookID</th>
                                        <th> &nbsp;</th>
                                        <th> Book name </th>
                                        <th> Category </th>
                                        <th> Author Name </th>
                                        <th> Published_Date </th>
                                        <th> &nbsp; </th>
                                        <th> Action </th>
                                      </tr>
                                <?php if(isset($book_list) && count($book_list)>0): ?>
                                    <?php $__currentLoopData = $book_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $id = !empty($book->id) ? $book->id :'' ;
                                            $name = !empty($book->name) ? $book->name :'' ;
                                            $category = !empty($book->category) ? $book->category :'' ;
                                            $image = !empty($book->image) ? $book->image :'' ;
                                            $author_name = !empty($book->author_name) ? $book->author_name :'' ;
                                            $published_date = !empty($book->published_date) ? date("d/m/Y", strtotime($book->published_date))  :'' ;
                                        ?>
                                    <tr class="edit-dis-table">
                                        <td>
                                            <?php echo e($id); ?>

                                            <input type="hidden" class="id" value="<?php echo e($id); ?>" />
                                        </td>
                                        <td class="py-1">
                                            <img src="<?php echo e(asset('/images/'.$image)); ?>" style="width: 50px;" height="50px" />
                                        </td>
                                        <td> <input type="text" class="form-control book_name" name="bookname" id="bookname" value="<?php echo e($name); ?>" disabled="" > </td>
                                        <td> <?php echo e($category); ?> </td>
                                        <td> <?php echo e($author_name); ?> </td>
                                        <td> <?php echo e($published_date); ?> </td>
                                        <td><span class="book_msg"></span></td>
                                        <td> 
                                            <ul class="list-inline m-0">
                                              <li class="list-inline-item">
                                                <a href="javascript:void();" class="btn btn-warning edit_bP tbl-edit-view-btn" onclick="update_book(this);">Edit</a>
                                                <a href="javascript:void();" onclick="save_book(this)" class="btn btn-success edit_bP hidden tbl-update-btn" >Update</a>
                                              </li>
                                              <li class="list-inline-item">
                                                <a href="javascript:void();" class="btn btn-danger delete_category" data-book-id="<?php echo e($id); ?>"  onclick="delete_book(this)">Delete</a>
                                            </li>
                                          </ul>
                                          </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr><td colspan="20" style="text-align: center"> No Records Found.</td></tr>
                                <?php endif; ?> 
                                </tbody>
                            </table>
                        </section>
                    </div>
                    <div class="col-md-12 text-right">
                        <div class="pull-right">
                          <?php if(!empty($book_list)): ?>
                            <?php echo e($book_list->links()); ?>

                          <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php echo $__env->make('layouts.footer_credit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>
        </section>
    </section>
</body>
<script>
    function update_book(this_id){
    if($(this_id).closest("tr").hasClass("edit-dis-table")){
      $(this_id).addClass("hidden");
      $(this_id).closest("td").find(".tbl-update-btn").removeClass("hidden");
      $(this_id).closest("td").find(".tbl-delete-btn").removeClass("hidden");
      $(this_id).closest("tr").removeClass("edit-dis-table");
      $(this_id).closest("tr").addClass("edit-enable-table");
      $(this_id).closest("tr").find(".form-control").removeAttr("disabled");
      }
    }
    
    function save_book(this_id){
        var book_id = $(this_id).closest("tr").find(".id").val();
        var book_name = $(this_id).closest("tr").find(".book_name").val();
        $.ajax({
            type: "POST",
            url: "/admin/update-book-details",
            data: {"_token" : "<?php echo e(csrf_token()); ?>",book_id:book_id,book_name:book_name},
            success: function (data,textStatus, jQxhr) {
                $(this_id).closest("tr").find(".book_msg").text("");
                if(data.success == 1){
                    $(this_id).closest("tr").find(".book_msg").css('color','green').text("Updated!!").show();
                }else{
                    $(this_id).closest("tr").find(".book_msg").css('color','red').text("Failed to update!!").show();
                }
                
                $(this_id).closest("tr").find(".tbl-edit-view-btn").removeClass("hidden");
                $(this_id).addClass("hidden");
                $(this_id).closest("tr").removeClass("edit-enable-table");
                $(this_id).closest("tr").addClass("edit-dis-table");
                $(this_id).closest("tr").find(".form-control").attr("disabled","disabled");
                setTimeout(function () {
                    $(this_id).closest("tr").find(".book_msg").hide();
                }, 1500);
              },
            error: function (jqXhr, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        });
    }
    
    function delete_book(this_id){
    
    var delete_confirmation = confirm("Do you want to delete this book?");
      if(!delete_confirmation) {
          return false;
      }
      var book_id = $(this_id).attr("data-book-id");
      $.ajax({
          type: "POST",
          url: "/admin/delete-book",
          data: {"_token" : "<?php echo e(csrf_token()); ?>",book_id : book_id},
          cache: false,
          success: function(data, textStatus, jQxhr) {
              if(data.success == 1) {
                window.location.reload();
              }
          },
          error: function(jqXhr, textStatus, errorThrown) {
              console.log(errorThrown);
          }
      });
    
    }
    
    </script>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\BooksManagementSystem\booksManagement\resources\views/books/book_list.blade.php ENDPATH**/ ?>