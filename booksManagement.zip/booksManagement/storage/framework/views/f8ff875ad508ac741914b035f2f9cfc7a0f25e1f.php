
<?php
$category_list = !empty($category_list) ? $category_list :'';
?>
<body>
    <section id="container" class="">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section id="main-content">
            <section class="wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header"><i class="fa fa-laptop"></i> Dashboard</h3>
                        <ol class="breadcrumb">
                            <li><i class="fa fa-home"></i><a href="/admin/dashboard">Home</a></li>
                            <li><i class="fa fa-laptop"></i>Add New Book</li>
                        </ol>
                    </div>
                </div>
                <?php if(count($errors) > 0): ?>
                <div class = "alert alert-danger">
                   <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </ul>
                </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-lg-12">
                        <section class="panel">
                            <header class="panel-heading">Add New Book</header>
                            <div class="panel-body">
                                <div class="form">
                                    <form class="form-validate form-horizontal" name="add_book_form" id="add_book_form" action="/admin/addnew-book" method="post" enctype="multipart/form-data">
                                        <?php if(session()->has('success')): ?>
                                        <div class="alert alert-success" id="alert-success"  style="padding: 7px 5px;">
                                              <?php echo e(session()->get('success')); ?>

                                        </div>
                                        <?php endif; ?>
                                        <?php if(session()->has('error')): ?>
                                        <?php $__currentLoopData = session()->get('error'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="alert alert-danger" id="alert-danger" style="padding: 7px 5px;">
                                                  <?php echo e($value); ?>

                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group ">
                                            <label for="booktitle" class="control-label col-lg-2">Book Title <span class="">*</span></label>
                                            <div class="col-lg-10">
                                                <input type="text" class="form-control" id="booktitle" name="booktitle" placeholder="Enter Book title"  />
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label for="author" class="control-label col-lg-2">Select Category <span class="">*</span></label>
                                            <div class="col-lg-10">
                                                <select class="form-control" id="category" name="category">
                                                    <option value="">Please Choose</option>
                                                    <?php if(!empty($category_list)): ?>
                                                       <?php $__currentLoopData = $category_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                          <option value="<?php echo e(!empty($category->name) ? $category->name :''); ?>"><?php echo e(!empty($category->name) ? $category->name :''); ?></option>
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                                    <?php endif; ?>                          
                                                 </select>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label for="curl" class="control-label col-lg-2">Author Name</label>
                                            <div class="col-lg-10">
                                                <input type="text" class="form-control" id="author_name" name="author_name" placeholder="Enter Author Name" value="">
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label for="curl" class="control-label col-lg-2">Upload Book Image</label>
                                            <div class="col-lg-10">
                                                <input type="file" class="form-control" id="image" name="image" />
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-lg-offset-2 col-lg-10">
                                                <button class="btn btn-primary" type="submit"  id="add_book" >Save</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <?php echo $__env->make('layouts.footer_credit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>
        </section>
    </section>
</body>
<script>

setTimeout(function() {
$('#alert-success').fadeOut('fast');
}, 3000); 

</script>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\BooksManagementSystem\booksManagement\resources\views/books/add_new_book.blade.php ENDPATH**/ ?>