<?php

namespace App\Repositories;
use App\Models\Book;
use App\Models\Category;
use Exception;

class BookRepository
{
    protected $book;
    protected $category;

     /**
     * Create a new repository instance.
     *
     * @param  book $book
     * @return void
     */
    public function __construct(Book $book, Category $category)
    {
        $this->book = $book;
        $this->category = $category;
    }

    public function CreateBook(array $data)
    { 
        try {
            return $this->book->Create($data);
        }catch(Exception $exception) {
            return false;
        }
    }

    public function getBookCategory($columns,$paginate)
    { 
        try {
            if(!empty($paginate)){
                return $this->category->select($columns)->orderBy('created_at', 'desc')->paginate($paginate);
            }else{
                return $this->category->select($columns)->orderBy('created_at', 'desc')->get();
            }
           
        }catch(Exception $exception) {
            return false;
        }
    }

    public function CreateCategory(array $data)
    { 
        try {
            return $this->category->Create($data);
        }catch(Exception $exception) {
            return false;
        }
    }

    public function updateBookCategory($attributes, $data)
    {
        try {
            return $this->category->updateOrCreate($attributes,$data);
        } catch (Exception $exception) {
            return false;
        }
    }

    public function getBookDetails($columns,$paginate)
    { 
        try {
            if(!empty($paginate)){
                return $this->book->select($columns)->orderBy('created_at', 'desc')->paginate($paginate);
            }else{
                return $this->book->select($columns)->orderBy('created_at', 'desc')->get();
            }
        }catch(Exception $exception) {
            return false;
        }
    }

    public function updateBookdetails($attributes, $data)
    {
        try {
            return $this->book->updateOrCreate($attributes,$data);
        } catch (Exception $exception) {
            return false;
        }
    }

    public function deleteBookCategory($attribute)
    { 
        try {
            return $this->category->where('id', $attribute)->delete();
        } catch (Exception $e) {
            return collect();
        }    
    }

    public function deleteBook($attribute)
    { 
        try {
            return $this->book->where('id', $attribute)->delete();
        } catch (Exception $e) {
            return collect();
        }    
    }
}
