<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Service\BookService;
use Validator;
use Auth;


class BookController extends Controller
{

    protected $bookService;

    /**
     * Create a new service instance.
     *
     * @param  Repository $repository
     * @return void
     */
    public function __construct(BookService $bookService)
    {
        $this->bookService = $bookService;
    }

    public function index(){

        $columns = ['*'];
        $paginate = null;
        $book_list = $this->bookService->getBookDetails($columns,$paginate );

        return view('index', compact('book_list'));
    }

    public function addNewBook(Request $request ){

        if($request->post()){
            $now = Carbon::now()->format('Y-m-d');
            $request->validate([
                'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                'booktitle' => 'required',
                'category' => 'required',
            ]);

            if($request->hasFile('image')){
                $imageName = time().'.'.$request->image->extension();  
                $request->image->move(public_path('images'), $imageName);
            }else{
                $imageName = "book-default.jpg";
            }
            
            $data = array (
                'name' => $request->booktitle,
                'category' => $request->category,
                'author_name' => $request->author_name,
                'image' => $imageName,
                'published_date' => $now,
            );

            if($this->bookService->CreateBook($data)){
                return redirect()->back()->with('success', 'Updated Successfully'); 
            }else{
                return redirect()->back()->with('error', 'Updating Error'); 
            }
        }
        $columns = ['id','name'];
        $paginate = null;
        $category_list = $this->bookService->getBookCategory($columns,$paginate );
        return view('books.add_new_book', compact('category_list'));
    }

    public function addNewCategory(Request $request ){
        if($request && $request->isMethod('post')){ 
            
            $this->validate(request(), [
                'category_name' => 'required',
            ]);

            $data = array (
                'name' => !empty($request->category_name) ? $request->category_name :'',
                'description' => !empty($request->description) ? $request->description :'',
            );
            if($this->bookService->CreateCategory($data)){
                return redirect()->back()->with('success', 'Updated Successfully'); 
            }else{
                return redirect()->back()->with('error', 'Updating Error'); 
            }
        }
        $columns = ['*'];
        $paginate = 10;
        $category_list = $this->bookService->getBookCategory($columns,$paginate );
        return view('categories.add_new_category', compact('category_list'));
    }

    public function updateBookCategory(Request $request) {
        $attributes = ['id'=>$request->cat_id];
        $data = ['name'=>$request->cat_name,'description'=>$request->cat_description];
        $res = $this->bookService->updateBookCategory($attributes, $data);
        if($res){
            $response['success'] = 1;
        }else{
            $response['success'] = 0;
        }
        return $response;
    }

    public function deleteBookCategory(Request $request) {
        $attributes = ['id'=>$request->cat_id];
        $res = $this->bookService->deleteBookCategory($attributes);
        if($res) {
            $response['success'] = 1;
        }else {
            $response['success'] = 0;
        }
        return $response;
    }

    public function bookList(){
        
        $columns = ['*'];
        $paginate = 10;
        $book_list = $this->bookService->getBookDetails($columns, $paginate);
        return view('books.book_list',compact('book_list'));
    }

    public function updateBookdetails(Request $request){
        $attributes = ['id'=>$request->book_id];
        $data = ['name'=>$request->book_name];
        $res = $this->bookService->updateBookdetails($attributes, $data);
        if($res){
            $response['success'] = 1;
        }else{
            $response['success'] = 0;
        }
        return $response;
    }

    public function deleteBook(Request $request) {
        $attributes = ['id'=>$request->book_id];
        $res = $this->bookService->deleteBook($attributes);
        if($res) {
            $response['success'] = 1;
        }else {
            $response['success'] = 0;
        }
        return $response;
    }
}
