<?php

namespace App\Service;

use App\Repositories\BookRepository;

class BookService
{
    protected $bookRepository;

    /**
     * Create a new service instance.
     *
     * @param  Repository $repository
     * @return void
     */
    public function __construct(BookRepository $bookRepository)
    {
        $this->bookRepository = $bookRepository;
    }

    public function CreateBook($data)
    {
        return $this->bookRepository->CreateBook($data);
    }

    public function getBookCategory($columns,$paginate)
    {
        return $this->bookRepository->getBookCategory($columns,$paginate);
    }

    public function CreateCategory($data)
    {
        return $this->bookRepository->CreateCategory($data);
    }

    public function updateBookCategory($attribute, $data)
    {
        return $this->bookRepository->updateBookCategory($attribute, $data);
    }

    public function getBookDetails($columns,$paginate)
    {
        return $this->bookRepository->getBookDetails($columns,$paginate);
    }

    public function deleteBookCategory($attribute)
    {
        return $this->bookRepository->deleteBookCategory($attribute);
    }

    public function updateBookdetails($attribute, $data)
    {
        return $this->bookRepository->updateBookdetails($attribute, $data);
    }
    
    public function deleteBook($attribute)
    {
        return $this->bookRepository->deleteBook($attribute);
    }




}