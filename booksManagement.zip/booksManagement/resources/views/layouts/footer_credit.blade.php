<section class="wrapper">
    <div class="text-right">
        <div class="credits">
            Designed by <a href="#">windya</a>
        </div>
    </div>
</section>