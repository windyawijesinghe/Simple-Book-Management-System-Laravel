@extends ('layouts.main')
<body>
    <section id="container" class="">
        @include ('layouts.sidebar')
        <section id="main-content">
            <section class="wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header"><i class="fa fa-laptop"></i> Dashboard</h3>
                    </div>
                    <div class="col-lg-10">
                        <ol class="breadcrumb">
                            <li><i class="fa fa-home"></i><a href="/admin/dashboard">Home</a></li>
                            <li><i class="fa fa-laptop"></i>Dashboard</li>
                        </ol>
                    </div>
                    <div class="col-lg-2">
                        <div class="btn">
                            <a href="/admin/addnew-book" button class="btn btn-primary btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="Add"> <i class="fa fa-plus" style="margin-right: 5px;"></i> Create</a>
                        </div>
                    </div>
                </div>
                <div class="row">
                @php
                    $book_list = !empty($book_list) ? $book_list :'';
                @endphp
                @if(isset($book_list) && count($book_list)>0)
                    @foreach($book_list as $book)
                        @php
                            $name = !empty($book->name) ? $book->name :'' ;
                            $image = !empty($book->image) ? $book->image :'' ;
                            $author_name = !empty($book->author_name) ? $book->author_name :'' ;
                            $published_date = !empty($book->published_date) ? date("d/m/Y", strtotime($book->published_date))  :'' ;
                        @endphp
                    <div class="col-lg-4">
                        <section class="panel">
                            <div class="panel-body">
                                <div class="thumbnail">
                                    <img class="group list-group-image" src="{{ asset('/images/'.$image) }}" style="height:100px; width:100px; margin-left: inherit;"alt="">
                                    <div class="caption" style=" padding-top: 16px;">
                                        <h4 class="group inner list-group-item-heading" style="font-weight: bold;"> {{ $name}}</h4>
                                        <p class="group inner list-group-item-heading">  Author : {{ $author_name}}</p>
                                        <div class="row">
                                            <div class="col-xs-12 col-md-12">
                                                <p class="lead " style="font-size: 15px;">{{$published_date}}</p>
                                            </div>
                                            @php
                                            $title = 'View'.' '.$name;
                                            @endphp
                                            <div class="btn">
                                                <a href="/admin/book-list" button class="btn btn-primary btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="{{$title}}"><i class="fa fa-eye" aria-hidden="true" style="margin-right: 5px;"></i> View Book</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    @endforeach
                @else
                    <tr><td colspan="20" style="text-align: center"> No Records Found.</td></tr>
                @endif
                </div>
                @include ('layouts.footer_credit')
            </section>
        </section>
    </section>
</body>