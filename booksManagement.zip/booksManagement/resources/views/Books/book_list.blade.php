@extends ('layouts.main')
<body>
    <section id="container" class="">
        @include ('layouts.sidebar')
        <section id="main-content">
            <section class="wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header"><i class="fa fa-laptop"></i> Dashboard</h3>
                        <ol class="breadcrumb">
                            <li><i class="fa fa-home"></i><a href="index.html">Home</a></li>
                            <li><i class="fa fa-laptop"></i>Book List</li>
                        </ol>
                    </div>
                </div>
                @php
                $book_list = !empty($book_list) ? $book_list :'';
                @endphp
                <div class="row">
                    <div class="col-lg-12">
                        <section class="panel">
                            <header class="panel-heading">Book List</header>
                            <table class="table table-striped table-advance table-hover">
                                <tbody>
                                    <tr>
                                        <th> BookID</th>
                                        <th> &nbsp;</th>
                                        <th> Book name </th>
                                        <th> Category </th>
                                        <th> Author Name </th>
                                        <th> Published_Date </th>
                                        <th> &nbsp; </th>
                                        <th> Action </th>
                                      </tr>
                                @if(isset($book_list) && count($book_list)>0)
                                    @foreach($book_list as $book)
                                        @php
                                            $id = !empty($book->id) ? $book->id :'' ;
                                            $name = !empty($book->name) ? $book->name :'' ;
                                            $category = !empty($book->category) ? $book->category :'' ;
                                            $image = !empty($book->image) ? $book->image :'' ;
                                            $author_name = !empty($book->author_name) ? $book->author_name :'' ;
                                            $published_date = !empty($book->published_date) ? date("d/m/Y", strtotime($book->published_date))  :'' ;
                                        @endphp
                                    <tr class="edit-dis-table">
                                        <td>
                                            {{ $id }}
                                            <input type="hidden" class="id" value="{{ $id }}" />
                                        </td>
                                        <td class="py-1">
                                            <img src="{{ asset('/images/'.$image) }}" style="width: 50px;" height="50px" />
                                        </td>
                                        <td> <input type="text" class="form-control book_name" name="bookname" id="bookname" value="{{$name}}" disabled="" > </td>
                                        <td> {{$category}} </td>
                                        <td> {{$author_name}} </td>
                                        <td> {{$published_date}} </td>
                                        <td><span class="book_msg"></span></td>
                                        <td> 
                                            <ul class="list-inline m-0">
                                              <li class="list-inline-item">
                                                <a href="javascript:void();" class="btn btn-warning edit_bP tbl-edit-view-btn" onclick="update_book(this);">Edit</a>
                                                <a href="javascript:void();" onclick="save_book(this)" class="btn btn-success edit_bP hidden tbl-update-btn" >Update</a>
                                              </li>
                                              <li class="list-inline-item">
                                                <a href="javascript:void();" class="btn btn-danger delete_category" data-book-id="{{ $id }}"  onclick="delete_book(this)">Delete</a>
                                            </li>
                                          </ul>
                                          </td>
                                    </tr>
                                    @endforeach
                                @else
                                    <tr><td colspan="20" style="text-align: center"> No Records Found.</td></tr>
                                @endif 
                                </tbody>
                            </table>
                        </section>
                    </div>
                    <div class="col-md-12 text-right">
                        <div class="pull-right">
                          @if(!empty($book_list))
                            {{ $book_list->links() }}
                          @endif
                        </div>
                    </div>
                </div>
                @include ('layouts.footer_credit')
            </section>
        </section>
    </section>
</body>
<script>
    function update_book(this_id){
    if($(this_id).closest("tr").hasClass("edit-dis-table")){
      $(this_id).addClass("hidden");
      $(this_id).closest("td").find(".tbl-update-btn").removeClass("hidden");
      $(this_id).closest("td").find(".tbl-delete-btn").removeClass("hidden");
      $(this_id).closest("tr").removeClass("edit-dis-table");
      $(this_id).closest("tr").addClass("edit-enable-table");
      $(this_id).closest("tr").find(".form-control").removeAttr("disabled");
      }
    }
    
    function save_book(this_id){
        var book_id = $(this_id).closest("tr").find(".id").val();
        var book_name = $(this_id).closest("tr").find(".book_name").val();
        $.ajax({
            type: "POST",
            url: "/admin/update-book-details",
            data: {"_token" : "{{csrf_token() }}",book_id:book_id,book_name:book_name},
            success: function (data,textStatus, jQxhr) {
                $(this_id).closest("tr").find(".book_msg").text("");
                if(data.success == 1){
                    $(this_id).closest("tr").find(".book_msg").css('color','green').text("Updated!!").show();
                }else{
                    $(this_id).closest("tr").find(".book_msg").css('color','red').text("Failed to update!!").show();
                }
                
                $(this_id).closest("tr").find(".tbl-edit-view-btn").removeClass("hidden");
                $(this_id).addClass("hidden");
                $(this_id).closest("tr").removeClass("edit-enable-table");
                $(this_id).closest("tr").addClass("edit-dis-table");
                $(this_id).closest("tr").find(".form-control").attr("disabled","disabled");
                setTimeout(function () {
                    $(this_id).closest("tr").find(".book_msg").hide();
                }, 1500);
              },
            error: function (jqXhr, textStatus, errorThrown) {
                console.log(errorThrown);
            }
        });
    }
    
    function delete_book(this_id){
    
    var delete_confirmation = confirm("Do you want to delete this book?");
      if(!delete_confirmation) {
          return false;
      }
      var book_id = $(this_id).attr("data-book-id");
      $.ajax({
          type: "POST",
          url: "/admin/delete-book",
          data: {"_token" : "{{csrf_token() }}",book_id : book_id},
          cache: false,
          success: function(data, textStatus, jQxhr) {
              if(data.success == 1) {
                window.location.reload();
              }
          },
          error: function(jqXhr, textStatus, errorThrown) {
              console.log(errorThrown);
          }
      });
    
    }
    
    </script>