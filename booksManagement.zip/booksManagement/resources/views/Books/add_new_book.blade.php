@extends ('layouts.main')
@php
$category_list = !empty($category_list) ? $category_list :'';
@endphp
<body>
    <section id="container" class="">
        @include ('layouts.sidebar')
        <section id="main-content">
            <section class="wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header"><i class="fa fa-laptop"></i> Dashboard</h3>
                        <ol class="breadcrumb">
                            <li><i class="fa fa-home"></i><a href="/admin/dashboard">Home</a></li>
                            <li><i class="fa fa-laptop"></i>Add New Book</li>
                        </ol>
                    </div>
                </div>
                @if (count($errors) > 0)
                <div class = "alert alert-danger">
                   <ul>
                      @foreach ($errors->all() as $error)
                         <li>{{ $error }}</li>
                      @endforeach
                   </ul>
                </div>
                @endif
                <div class="row">
                    <div class="col-lg-12">
                        <section class="panel">
                            <header class="panel-heading">Add New Book</header>
                            <div class="panel-body">
                                <div class="form">
                                    <form class="form-validate form-horizontal" name="add_book_form" id="add_book_form" action="/admin/addnew-book" method="post" enctype="multipart/form-data">
                                        @if(session()->has('success'))
                                        <div class="alert alert-success" id="alert-success"  style="padding: 7px 5px;">
                                              {{ session()->get('success') }}
                                        </div>
                                        @endif
                                        @if(session()->has('error'))
                                        @foreach(session()->get('error') as $key => $value)
                                            <div class="alert alert-danger" id="alert-danger" style="padding: 7px 5px;">
                                                  {{ $value }}
                                            </div>
                                            @endforeach
                                        @endif
                                        @csrf
                                        <div class="form-group ">
                                            <label for="booktitle" class="control-label col-lg-2">Book Title <span class="">*</span></label>
                                            <div class="col-lg-10">
                                                <input type="text" class="form-control" id="booktitle" name="booktitle" placeholder="Enter Book title"  />
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label for="author" class="control-label col-lg-2">Select Category <span class="">*</span></label>
                                            <div class="col-lg-10">
                                                <select class="form-control" id="category" name="category">
                                                    <option value="">Please Choose</option>
                                                    @if(!empty($category_list))
                                                       @foreach($category_list as $category)
                                                          <option value="{{!empty($category->name) ? $category->name :''}}">{{ !empty($category->name) ? $category->name :''}}</option>
                                                       @endforeach  
                                                    @endif                          
                                                 </select>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label for="curl" class="control-label col-lg-2">Author Name</label>
                                            <div class="col-lg-10">
                                                <input type="text" class="form-control" id="author_name" name="author_name" placeholder="Enter Author Name" value="">
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label for="curl" class="control-label col-lg-2">Upload Book Image</label>
                                            <div class="col-lg-10">
                                                <input type="file" class="form-control" id="image" name="image" />
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-lg-offset-2 col-lg-10">
                                                <button class="btn btn-primary" type="submit"  id="add_book" >Save</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                @include ('layouts.footer_credit')
            </section>
        </section>
    </section>
</body>
<script>

setTimeout(function() {
$('#alert-success').fadeOut('fast');
}, 3000); 

</script>